#ifndef DS_RATIO_H
#define DS_RATIO_H

#include <iostream>
#include <string>

namespace ds_course {
    class Ratio {
        //private:
        public:
        int num; // numerator
        int den; // denominator
        Ratio(int = 0, int = 1); // allows default constructor creating 0/1
        Ratio operator+(const Ratio& r);
        Ratio operator-(const Ratio& r);
        Ratio operator*(const Ratio& r);
        Ratio operator/(const Ratio& r);
        bool operator<(const Ratio& r);
        bool operator>(const Ratio& r);
        bool operator==(const Ratio& r);

        int getNum() const;
        int getDen() const;
        friend std::ostream& operator<<(std::ostream& rOs, const ds_course::Ratio& rat) {
            rOs << rat.num << "/" << rat.den;
            return rOs;
        }

        friend std::istream& operator>>(std::istream &input, ds_course::Ratio& rat) {
            input >> rat.num;
            input.ignore(16, '/'); // ignore slash
            input >> rat.den; 
            return input;
        }
    };
};

int gcd(int a, int b) {
    if (b == 0) { return a; }    
    return gcd(b, a % b);
}

ds_course::Ratio::Ratio(int nn, int dd): num(nn), den(dd)  {
    int g = gcd(num, den);
    num = num/g;
    den = den/g;
    if (den < 0) {
        num = -num;
        den = -den;
    }
}

int ds_course::Ratio::getNum() const {
	return num;
}

int ds_course::Ratio::getDen() const {
	return den;
}


ds_course::Ratio ds_course::Ratio::operator+(const ds_course::Ratio& r) {
    Ratio result;
    result = Ratio(num * r.den + r.num * den, den * r.den);
    return result;
}

ds_course::Ratio ds_course::Ratio::operator-(const ds_course::Ratio& r) {
    Ratio result;
    result = Ratio(num * r.den - r.num * den, den * r.den);
    return result;
}

ds_course::Ratio ds_course::Ratio::operator*(const ds_course::Ratio& r) {
    Ratio result;
    result = Ratio(num * r.num, den * r.den);
    return result;
}

ds_course::Ratio ds_course::Ratio::operator/(const ds_course::Ratio& r) {
    Ratio result;
    result = Ratio(num * r.den, den * r.num);
    return result;
}

bool ds_course::Ratio::operator<(const ds_course::Ratio& r) {    
    return (num * r.den < den * r.num);
}

bool ds_course::Ratio::operator>(const ds_course::Ratio& r) {    
    return (num * r.den > den * r.num);
}

bool ds_course::Ratio::operator==(const ds_course::Ratio& r) {    
    return (num * r.den == den * r.num);
}



#endif /* DS_RATIO_H */

