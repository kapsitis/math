#include <iostream>
#include <string>
#include "Ratio.h"
#include "Matrix.h"
  
using namespace std;
using namespace ds_course;

int main() {
	// 	string ttt;
	// int rrr, ccc;

	// cin >> ttt;
	// cin >> rrr >> ccc;

	// Ratio r;
	// cin >> r;
	// cout << r;
	// return 0;

	string type1, type2;
	int rows1, cols1;
	int rows2, cols2;
	string operation; 
	cin >> type1;
	if (type1 == "MZ") {
		cin >> rows1 >> cols1;
		Matrix<int> m1(rows1,cols1);
		cin >> m1;
		cin >> type2;
		cin >> rows2 >> cols2;
		Matrix<int> m2(rows2,cols2);
		cin >> m2;
		cin >> operation;
		try {
			if (operation == "ADD") {
				Matrix<int> m3 = m1 + m2;
				cout << m3;
			}
			else if (operation == "SUB") {
				Matrix<int> m3 = m1 - m2;
				cout << m3;
			}
			else if (operation == "MUL") {
				Matrix<int> m3 = m1 * m2;
				cout << m3;
			} else {
				cerr << "Unknown operation\n";
			}
		} catch (const std::out_of_range& e) {
    		cout << "out_of_range";
		}
	} else if (type1 == "MQ") {
		cin >> rows1 >> cols1;
		cerr << "MQ rows1 = " << rows1 << ", " << "cols1 = " << cols1 << endl;
		Matrix<Ratio> m1(rows1,cols1);
		cerr << "MQ AA" << endl; 
		cin >> m1;
		
		cin >> type2;
		cin >> rows2 >> cols2;
		cerr << "MQ rows2 = " << rows1 << ", " << "cols2 = " << cols1 << endl;
		cerr << "MQ BB" << endl; 
		Matrix<Ratio> m2(rows2,cols2);
		cerr << "MQ CC" << endl; 
		cin >> m2;
		cerr << "MQ DD" << endl; 
		cin >> operation;
		try {
			if (operation == "ADD") {
				Matrix<Ratio> m3 = m1 + m2;
				cout << m3;
			}
			else if (operation == "SUB") {
				Matrix<Ratio> m3 = m1 - m2;
				cout << m3;
			}
			else if (operation == "MUL") {
				Matrix<Ratio> m3 = m1 * m2;
				cout << m3;
			} else {
				cerr << "Unknown operation\n";
			}
		} catch (const std::out_of_range& e) {
    		cout << "out_of_range";
		}
	 }
	
	 else if (type1 == "MR") {
		cin >> rows1 >> cols1;
		Matrix<double> m1(rows1,cols1);
		cin >> m1;
		cin >> type2;
		cin >> rows2 >> cols2;
		Matrix<double> m2(rows2,cols2);
		cin >> m2;
		cin >> operation;
		try {
			if (operation == "ADD") {
				Matrix<double> m3 = m1 + m2;
				cout << m3;
			}
			else if (operation == "SUB") {
				Matrix<double> m3 = m1 - m2;
				cout << m3;
			}
			else if (operation == "MUL") {
				Matrix<double> m3 = m1 * m2;
				cout << m3;
			} else {
				cerr << "Unknown operation\n";
			}
		} catch (const std::out_of_range& e) {
    		cout << "out_of_range";
		}
	} else {
		cerr << "Unknown matrix type\n";
	}
}

