#include <string>

namespace ds_course
{
    class Palindromes
    {
    public:
    Palindromes(); 
    bool isPalindrome(int number);
    bool isPalindrome(std::string word);
    };
}


